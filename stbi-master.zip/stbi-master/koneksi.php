<?php
$host="localhost";
$user="root";
$password="";
$database="dbstbi";
$koneksi=mysql_connect($host,$user,$password,$database);
mysql_select_db($database,$koneksi);
/*test koneksi*/
if($koneksi){
echo "Sukses Koneksi ke Database";
}else{
echo "Failed Koneksi ke Database";
}
?>